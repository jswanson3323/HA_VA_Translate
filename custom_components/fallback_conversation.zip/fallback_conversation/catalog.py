from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Set

from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers import area_registry as ar
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er

_LOGGER = logging.getLogger(__name__)

DEFAULT_DOMAINS: Set[str] = {
    "light",
    "switch",
    "fan",
    "cover",
    "climate",
    "script",
    "scene",
    "input_boolean",
    "lock",
}

CACHE_TTL_SECONDS = 60


@dataclass(frozen=True)
class EntityCatalogItem:
    entity_id: str
    domain: str
    name: str
    area_name: Optional[str]
    device_name: Optional[str]


class EntityCatalog:
    """Catalog of likely voice-controllable entities (version-proof)."""

    def __init__(self, hass: HomeAssistant, *, domains: Optional[Set[str]] = None) -> None:
        self.hass = hass
        self.domains = domains or set(DEFAULT_DOMAINS)

        self._lock = asyncio.Lock()
        self._built_at: float = 0.0
        self._items: List[EntityCatalogItem] = []
        self._by_id: Dict[str, EntityCatalogItem] = {}
        self._unsubs: List[callable] = []

    async def async_start(self) -> None:
        ent_reg = er.async_get(self.hass)
        dev_reg = dr.async_get(self.hass)
        area_reg = ar.async_get(self.hass)

        self._unsubs.append(ent_reg.async_listen(self._on_registry_changed))
        self._unsubs.append(dev_reg.async_listen(self._on_registry_changed))
        self._unsubs.append(area_reg.async_listen(self._on_registry_changed))

        await self.async_rebuild(force=True)

    async def async_stop(self) -> None:
        for unsub in self._unsubs:
            try:
                unsub()
            except Exception:
                pass
        self._unsubs.clear()

    async def async_get_items(self) -> List[EntityCatalogItem]:
        if (time.time() - self._built_at) > CACHE_TTL_SECONDS:
            await self.async_rebuild()
        return self._items

    async def async_rebuild(self, *, force: bool = False) -> None:
        async with self._lock:
            if not force and (time.time() - self._built_at) <= CACHE_TTL_SECONDS:
                return

            items, by_id = await self._build()
            self._items = items
            self._by_id = by_id
            self._built_at = time.time()
            _LOGGER.debug("EntityCatalog rebuilt: %d entities", len(items))

    async def _build(self) -> tuple[List[EntityCatalogItem], Dict[str, EntityCatalogItem]]:
        ent_reg = er.async_get(self.hass)
        dev_reg = dr.async_get(self.hass)
        area_reg = ar.async_get(self.hass)

        out: List[EntityCatalogItem] = []
        by_id: Dict[str, EntityCatalogItem] = {}

        for entry in ent_reg.entities.values():
            entity_id = entry.entity_id
            domain = entity_id.split(".", 1)[0]

            if domain not in self.domains:
                continue

            # Skip disabled/hidden entities (these are very unlikely to be intended for Assist)
            if entry.disabled:
                continue
            if entry.hidden_by is not None:
                continue

            # Friendly name: registry -> state -> entity_id
            friendly = entry.name
            if not friendly:
                st = self.hass.states.get(entity_id)
                friendly = st.attributes.get("friendly_name") if st else None
            if not friendly:
                friendly = entity_id

            device_name: Optional[str] = None
            area_name: Optional[str] = None

            area_id = entry.area_id
            if entry.device_id:
                dev = dev_reg.devices.get(entry.device_id)
                if dev:
                    device_name = dev.name_by_user or dev.name
                    area_id = area_id or dev.area_id

            if area_id:
                area = area_reg.areas.get(area_id)
                area_name = area.name if area else None

            item = EntityCatalogItem(
                entity_id=entity_id,
                domain=domain,
                name=str(friendly),
                area_name=area_name,
                device_name=device_name,
            )
            out.append(item)
            by_id[entity_id] = item

        return out, by_id

    @callback
    def _on_registry_changed(self, _event) -> None:
        self.hass.async_create_task(self.async_rebuild(force=True))


_DATA_KEY = "fallback_conversation_entity_catalog"


async def async_get_exposed_catalog(
    hass: HomeAssistant,
    *,
    assistant: str = "conversation",
    domains: Optional[Set[str]] = None,
):
    # 'assistant' kept for signature compatibility with your conversation.py
    cat: EntityCatalog | None = hass.data.get(_DATA_KEY)
    if cat is None:
        cat = EntityCatalog(hass, domains=domains)
        hass.data[_DATA_KEY] = cat
        await cat.async_start()
    return cat